
import express from "express";
import multer from "multer";
import fetch from "node-fetch";
import cors from "cors";
import FormData from "form-data";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const storage = multer.memoryStorage();
const upload = multer({ storage });

app.post("/generate", upload.single("imagen"), async (req, res) => {
  try {
    const foto = req.file;
    const productId = req.body.productId;
    const variantId = req.body.variantId;
    const idea = req.body.ideaCliente;
    const modo = req.body.modo;
    const sessionId = req.body.sessionId;

    if (!foto) return res.status(400).json({ error: "No se envió imagen" });

    const formData = new FormData();
    formData.append("file", foto.buffer, { filename: foto.originalname });
    formData.append("productId", productId || "");
    formData.append("variantId", variantId || "");
    formData.append("ideaCliente", idea || "");
    formData.append("modo", modo || "");
    formData.append("sessionId", sessionId || "");

    const resp = await fetch("https://hook.us2.make.com/qivxcdn5j6x08ei2fwqkrkxlp4nomr1f", {
      method: "POST",
      body: formData
    });

    const data = await resp.text();
    res.status(200).send(data);
  } catch (err) {
    console.error("ERROR:", err);
    res.status(500).json({ error: "Backend error", detail: err.message });
  }
});

app.get("/", (req, res) => {
  res.send("Innotiva Vision Backend Opción B - ONLINE");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("🔥 Backend Opción B escuchando en puerto " + PORT));
